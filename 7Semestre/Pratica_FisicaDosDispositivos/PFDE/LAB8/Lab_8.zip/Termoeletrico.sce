//%Programa:Termoeletrico.sce
clear;
//Parte-I: V2 vs. P1
V1a = [0 1.031 1.990 2.94 3.89 4.88 5.96 6.89];
I1a = [0 0.28 0.53 0.76 0.97 1.16 1.32 1.47];
V2a = [0 50.4e-3 97.3e-3 144.1e-3 190.2e-3 0.239 0.288 0.329];
P1a = V1a.*I1a;
scf(1);
plot(P1a,V2a,'or');

//Parte-II: P2 vs. P1
V1b = [0 1.010 1.990 2.93 4.04 4.97 5.93 6.83];
I1b = [0 0.25 0.47 0.68 0.91 1.05 1.23 1.34];
V2b = [0 24.6e-3 48.7e-3 72.7e-3 100.1e-3 119.1e-3 142.6e-3 156.2e-3];
R2b = 4.95; //[ohms]
I2b = V2b./R2b;
P1b = V1b.*I1b;
P2b = V2b.*I2b;
scf(2);
plot(P1b,P2b,'ob');

//Ajuste Linearizado da Parte-I
//Modelo: y = k*sqrt(x) 
g = sqrt(P1a); //Função Base
f = V2a; 
k = sum(f.*g)/sum(g.*g); //Ajuste da Constante do Modelo
disp(k);
scf(1);
N = 100;
x = linspace(0,max(P1a),N);
y = k*sqrt(x);
plot(x, y,'b');
title('V2 vs. P1');
xlabel('P1 [W]');
ylabel('V2 [V]');

//Ajuste Linear da Parte-II
//Modelo: y = eta*x 
g = P1b; //Função Base
f = P2b; 
eta = sum(f.*g)/sum(g.*g); //Ajuste da Constante do Modelo
disp(eta);
scf(2);
N = 100;
x = linspace(0,max(P1b),N);
y = eta*x;
plot(x, y,'r');
title('P2 vs. P1');
xlabel('P1 [W]');
ylabel('P2 [W]');









